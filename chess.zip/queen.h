#ifndef QUEEN_H
#define QUEEN_H
#include "piece.h"
#include "colour.h"
#include "movetype.h"

class Board;

class Queen : public Piece {

public:
        Queen(Board* board, char pieceName, Colour owner) : Piece(board, pieceName, owner) {}
        int getVal() override {return 9;}
        MoveType touchable(const Position position) override;

};


#endif  
