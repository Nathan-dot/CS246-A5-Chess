#ifndef MOVETYPE_H
#define MOVETYPE_H

enum class MoveType {Illegal, Legal, Castling, Promotion, EnPassant};



#endif

