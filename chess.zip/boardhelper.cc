#include "boardhelper.h"
#include "board.h"
#include "position.h"
#include "cell.h"
#include "piece.h"
#include "move.h"

std::vector<Move> legalMove(Board& board, Piece* piece) {
	std::vector<Move> moves;
 	Position position = piece->getPosition();
 	if (position.row == -1 || position.col == -1) {
		return moves;
	}
 	for (int i = 0; i < 8; ++i) {
  		for (int j = 0; j < 8; ++j) {
   			Position pos(i, j);
   			if (piece->move(pos) != MoveType::Illegal) {
    				Move curr;
    				curr.movingPiece = piece;
   				curr.initialPos = position;
   				curr.finalPos = pos;
    				moves.push_back(curr);
   			}
  		}
 	}
 	return moves;
}


