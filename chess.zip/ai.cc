#include "ai.h"
#include "board.h"
#include "position.h"
#include "cell.h"
#include "piece.h"
#include "move.h"

std::vector<Move> legalMove(Board& board, Piece* p) {
	std::vector<Move> vec;
 	Position posn = p->getPosition();
 	if (posn.compare(Position(-1, -1))) {
		return vec;
	}
 	for (int r = 0; r < 8; r++) {
  		for (int c = 0; c < 8; c++) {
   			Position pos(r, c);
   			if (p->move(pos) != MoveType::Illegal) {
    				Move curr;
    				curr.movingPiece = p;
   				curr.initialPos = posn;
   				curr.finalPos = pos;
    				vec.push_back(curr);
   			}
  		}
 	}
 	return vec;
}


