#ifndef __BOARDHELPER_H__
#define __BOARDHELPER_H__
#include <vector>
#include "colour.h"

struct Move;
class Position;
class Piece;
class Board;


std::vector<Move> legalMove(Board& board, Piece* piece);

#endif
