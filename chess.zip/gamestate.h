#ifndef GAMESTATE_H
#define GAMESTATE_H

enum class GameState {Draw, NoEnd, Resign, Check, Checkmate, Error, Undo, History};



#endif
