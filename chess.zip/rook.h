#ifndef ROOK_H
#define ROOK_H
#include "piece.h"
#include "colour.h"
#include "movetype.h"

class Board;

class Rook : public Piece {

public:
	Rook(Board* board, char pieceName, Colour owner): Piece(board, pieceName, owner) {}
	int getVal() override {return 5;}
        MoveType touchable(const Position position) override;

};





#endif
